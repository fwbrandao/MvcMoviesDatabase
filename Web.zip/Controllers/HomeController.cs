﻿using MvcMovieVS.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcMovieVS.Models;
using System.Data.Entity;

namespace MvcMovieVS.Controllers
{
	public class HomeController : Controller
	{
		//MvcMovieVSEntities db = new MvcMovieVSEntities();

		MvcFernandoMovieEntities db = new MvcFernandoMovieEntities();

		public ActionResult Index(string movieGenre, string searchString)
		{
			//genre search
			//get data db for genre drop-down list
			var GenreList = new List<String>();
			var GenreQuery = from g in db.Movies
							 orderby g.Genre
							 select g.Genre;

			GenreList.AddRange(GenreQuery.Distinct());
			//make list odf genres available to the view
			ViewBag.movieGenre = new SelectList(GenreList);


			//LINQ query
			var movies = from m in db.Movies
						 select m;
			//last bit of the genre search
			if(! string.IsNullOrEmpty(movieGenre))
			{
				movies = movies.Where(x => x.Genre == movieGenre);
			}

			//title search
			if (!string.IsNullOrEmpty(searchString))
			{
				movies = movies.Where(x => x.Title.Contains(searchString));
			}


			return View(movies);
		}

		public ActionResult Create()
		{
			return View();
		}
		[HttpPost]
		public ActionResult Create(Movie movie)
		{
			if (ModelState.IsValid)
			{
				db.Movies.Add(movie);
				db.SaveChanges();
				return RedirectToAction("Index");
			}

			return View(movie);

		}

		public ActionResult Details(int? id)
		{
			Movie movie = db.Movies.Find(id);

			return View(movie);

		}

		public ActionResult Edit(int? id)
		{

			Movie movie = db.Movies.Find(id);

			return View(movie);

		}

		[HttpPost]
		public ActionResult Edid(Movie movie)
		{

			if (ModelState.IsValid)
			{
				db.Entry(movie).State = EntityState.Modified;
				db.SaveChanges();
				return RedirectToAction("Index");
			}

			return View(movie);

		}

		public ActionResult Delete(int? id)
		{
			Movie movie = db.Movies.Find(id);

			return View(movie);

		}

		[HttpPost, ActionName("Delete")]
		public ActionResult DeleteConfirmed(int? id)
		{
			Movie movie = db.Movies.Find(id);
			db.Movies.Remove(movie);
			db.SaveChanges();
			return RedirectToAction("Index");
		}

	}
}