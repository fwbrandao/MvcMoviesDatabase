﻿namespace MvcMovieVS.Controllers
{
	internal class MvcMovieVSEntities
	{
	}
}