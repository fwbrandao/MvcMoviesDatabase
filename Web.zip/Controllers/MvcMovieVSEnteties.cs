﻿namespace MvcMovieVS.Controllers
{
	internal class MvcMovieVSEnteties
	{
		public object Movies { get; internal set; }
	}
}